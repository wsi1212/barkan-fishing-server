# Barkan Forage Pack v1 — 11 handcrafted 3D foraging props
CraftEngine furniture: mushrooms x8, apple, berry bush, magic herb.
Install: drop `configuration/` + `resourcepack/` into your CraftEngine pack namespace, `/ce reload all`.
Items: barkan:forage_mushred, barkan:forage_mushblue, barkan:forage_mushorange, barkan:forage_herb, barkan:forage_berry, barkan:forage_fruit, barkan:forage_mushtable, barkan:forage_mushshelf, barkan:forage_mushcluster, barkan:forage_mushtall, barkan:forage_mushpink
Built with pixel-forge modelkit (zone shading / painted rounding / material gloss-matte / contact AO).
Original models & textures. Palette direction referenced from public product imagery. Server-use license.
